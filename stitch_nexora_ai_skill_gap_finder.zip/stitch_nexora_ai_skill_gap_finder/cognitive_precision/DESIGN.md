---
name: Cognitive Precision
colors:
  surface: '#f9f9ff'
  surface-dim: '#d3daee'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f3ff'
  surface-container: '#e9edff'
  surface-container-high: '#e2e8fc'
  surface-container-highest: '#dce2f6'
  on-surface: '#151b2a'
  on-surface-variant: '#464555'
  inverse-surface: '#2a3040'
  inverse-on-surface: '#edf0ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#712ae2'
  on-secondary: '#ffffff'
  secondary-container: '#8a4cfc'
  on-secondary-container: '#fffbff'
  tertiary: '#005338'
  on-tertiary: '#ffffff'
  tertiary-container: '#006e4b'
  on-tertiary-container: '#67f4b7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#eaddff'
  secondary-fixed-dim: '#d2bbff'
  on-secondary-fixed: '#25005a'
  on-secondary-fixed-variant: '#5a00c6'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f9f9ff'
  on-background: '#151b2a'
  surface-variant: '#dce2f6'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.005em
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  metric-val:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system targets career-driven professionals, enterprise HR leaders, and ambitious lifelong learners navigating AI-driven market transitions. The product aesthetic balances the authoritative trust of institutional intelligence with the kinetic momentum of next-generation machine learning.

The design movement merges Modern Corporate Precision with Subtle Glassmorphic Luster. It emphasizes rigorous clarity, high-density data legibility, and refined spatial composure. The interface avoids aggressive neo-brutalist tropes or playful toy-like roundness, favoring calm, surgical efficiency. Visual accents—such as micro-borders, low-intensity indigo edge blooms, and structured metric containers—evoke an analytical diagnostic environment that feels intelligent, empowering, and profoundly competent.

## Colors

The palette establishes cognitive hierarchy through strict contrast tiers:

- **Canvas & Structural Surfaces**: The base application canvas rests on clean light slate (`#F8FAFC`), layering inward to pure white (`#FFFFFF`) containers and tinted indigo wash accents (`#EEF2FF`).
- **Primary & Secondary Spectrum**: Primary Indigo (`#4F46E5`) drives actionable elements, navigational emphasis, and key target paths. Electric Purple (`#7C3AED`) is reserved strictly for AI synthesis, predictive recommendations, and skill vector analysis. Soft Blue (`#6366F1`) handles secondary action states and informational telemetry.
- **Deep Navy Neutrals**: Headings and core typographic elements utilize deep slate-navy (`#0B1220`), supported by `#111C35` for secondary headers, `#475569` for body prose, and `#94A3B8` for subtle metadata and inactive boundaries.
- **Validation Accents**: Success metrics and verified proficiencies leverage Forest Mint (`#10B981`), while skill deficits and warnings utilize Amber (`#F59E0B`).

Dark elements are deployed strategically within light mode as anchored context modules (e.g., terminal analysis, graph tooltips, and elevated navigation bars) using `#0B1220` with fine structural border lines.

## Typography

The pairing between Plus Jakarta Sans and Inter creates a sharp balance of technical authority and human clarity:

- **Display & Headings (Plus Jakarta Sans)**: Carries geometric weight with tight negative letter tracking to produce authoritative anchors for dashboards, page titles, and skill cluster names.
- **Reading, Forms & Data Tables (Inter)**: Handles complex relational skill networks, detailed rubrics, course descriptions, and interface controls. Optical proportions remain clear even in dense analytic visualizations.
- **Metric Values**: Dedicated tracking and vertical heights ensure figures align across comparison modules, benchmark matrices, and score tiles without vertical jitter.
- **Labeling & Status Caps**: Small metadata tokens enforce slight positive tracking (`+0.04em`) to maintain legibility when rendered within badges, progress rings, or table headers.

## Layout & Spacing

The layout follows an analytical 12-column responsive fluid grid with strict mathematical proportions based on an 8pt spatial baseline:

- **Desktop (1280px+)**: 12 columns, 24px (`1.5rem`) gutters, and dynamic outer margins up to a maximum container constraint of 1440px. Multi-panel diagnostic dashboards partition into standard ratios (e.g., 3-col profile & skill filter sidebar, 9-col graph/matrix pane).
- **Tablet (768px - 1279px)**: 8 columns, 20px gutters, 24px outer margins. Tertiary telemetry collapses into layered drawer sheets or stacked blocks.
- **Mobile (< 768px)**: 4 columns, 16px (`1rem`) gutters, 16px margins. Complex multi-node visualizers transform into linear sequential cards with horizontal-scroll pill matrices.

Internal container padding must scale alongside hierarchy: dense metric cards employ `space-md` (16px), major workspace cards leverage `space-lg` (24px), and page sections isolate via `space-xl` (40px).

## Elevation & Depth

Visual hierarchy uses crisp boundary delineation, surface luminescence, and subtle depth planes instead of heavy, muddy drop-shadows:

- **Surface Layer 0 (Canvas)**: `#F8FAFC` base surface, flat.
- **Surface Layer 1 (Standard Card)**: Pure `#FFFFFF` fill bounded by a crisp 1px perimeter border of `#E2E8F0`. Elevation is anchored by an ambient drop: `0px 1px 3px rgba(11, 18, 32, 0.04), 0px 6px 16px -4px rgba(11, 18, 32, 0.03)`.
- **Surface Layer 2 (Interactive Floating / Active State)**: Pure `#FFFFFF` fill with an indigo-tinted border (`rgba(79, 70, 229, 0.25)`), elevated by `0px 10px 25px -5px rgba(79, 70, 229, 0.08), 0px 8px 10px -6px rgba(11, 18, 32, 0.03)`.
- **Surface Layer 3 (Modals, Slide-overs & Flyouts)**: `#FFFFFF` backdrop with a dual boundary ring: 1px outer `#CBD5E1` and an inner edge highlight. Shadow: `0px 20px 32px -8px rgba(11, 18, 32, 0.12), 0px 4px 12px -2px rgba(11, 18, 32, 0.04)`.
- **AI Luster Overlay (Diagnostic & Prediction Surfaces)**: Frosted glass finish using `backdrop-filter: blur(12px)`, background `rgba(255, 255, 255, 0.85)`, and a hairline 1px border gradient transitioning from `rgba(124, 58, 237, 0.3)` to `rgba(79, 70, 229, 0.1)`.

## Shapes

The geometric framework applies structural consistency with a modern, tailored radius:

- **Base Radius (`rounded-md`, 8px)**: Standard form controls, input fields, dropdown trigger buttons, tooltips, and table cell tags.
- **Intermediate Radius (`rounded-lg`, 16px)**: Sub-panels, list cards, contextual dialog boxes, and segmented controls.
- **Macro Enclosure (`rounded-xl`, 24px)**: Primary dashboard containers, AI summary cards, and parent diagnostic modules.
- **Full Pill (`rounded-full`, 9999px)**: Filter chips, status badges, indicator avatars, and standalone circular action triggers.

Sharp edges are avoided entirely; boundary continuity ensures technical density without feeling clinical or harsh.

## Components

### Buttons
- **Primary Action**: Solid `#4F46E5` fill, `#FFFFFF` text, 8px radius, height 40px (desktop) / 44px (mobile), padding `0 18px`. Hover: `#4338CA` with an ambient glow (`box-shadow: 0 0 16px rgba(79, 70, 229, 0.35)`). Active: scale `0.99`.
- **AI Action**: Gradient fill from `#4F46E5` to `#7C3AED`, `#FFFFFF` text, paired with a dynamic micro-sparkle icon. Hover: increased saturation and a soft edge glow.
- **Secondary / Ghost**: Pure `#FFFFFF` surface, 1px border of `#E2E8F0`, text `#111C35`. Hover: `#F8FAFC` background with border `#CBD5E1`.

### Chips & Badges
- **Status Badges**: Pill-shaped (`rounded-full`), height 24px, padding `2px 10px`. 
  - *Proficient*: Background `#ECFDF5`, text `#065F46`, 1px border `#A7F3D0`.
  - *Skill Gap*: Background `#FEF3C7`, text `#92400E`, 1px border `#FDE68A`.
  - *AI Emerging*: Background `#F5F3FF`, text `#5B21B6`, 1px border `#DDD6FE`.
- **Filter Chips**: Height 32px, radius 8px, `#FFFFFF` background, 1px `#E2E8F0` border. Active state features `#EEF2FF` fill with a `#4F46E5` border and text.

### Form Inputs & Selectors
- **Text Inputs**: Height 42px, radius 8px, `#FFFFFF` surface with 1px border `#CBD5E1`. Placeholder `#94A3B8`. 
- **Focus State**: Border transitions to `#4F46E5` accompanied by an explicit focus ring: `0 0 0 3px rgba(79, 70, 229, 0.15)`.

### Checkboxes & Radios
- **Checkbox**: 18px square with a 4px radius, 1.5px border `#CBD5E1`. Checked state: `#4F46E5` fill with a centered `#FFFFFF` checkmark icon.
- **Radio**: 18px circle, 1.5px border `#CBD5E1`. Checked state: 5px solid `#4F46E5` inner dot surrounded by `#FFFFFF` fill within the active boundary.

### Cards & Container Panels
- **Standard Skill Card**: 16px radius, `#FFFFFF` fill, 1px perimeter border `#E2E8F0`. Padding `20px`. Top-right quadrant features a normalized proficiency gauge or delta indicator.
- **AI Insight Card**: Subtle frosted gradient surface (`rgba(255, 255, 255, 0.9)`), border `1px solid rgba(124, 58, 237, 0.2)`. Features a top-border accent line in Electric Purple (`#7C3AED`) with an accompanying contextual recommendation pill.

### Skill Metrics & Progress Visualizers
- **Proficiency Trackers**: Linear bars with a 6px height, background `#EEF2FF`, and `rounded-full` caps. Active fill leverages an indigo-to-purple gradient (`#4F46E5` to `#7C3AED`). 
- **Benchmark Indicators**: Subtle vertical marker needles in `#0B1220` overlaid on progress tracks to denote target job requirements versus current evaluated capability.
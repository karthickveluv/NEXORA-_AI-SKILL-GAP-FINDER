---
name: AI Career Intelligence
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#464555'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#712ae2'
  on-secondary: '#ffffff'
  secondary-container: '#8a4cfc'
  on-secondary-container: '#fffbff'
  tertiary: '#00505f'
  on-tertiary: '#ffffff'
  tertiary-container: '#006a7c'
  on-tertiary-container: '#93e8ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#eaddff'
  secondary-fixed-dim: '#d2bbff'
  on-secondary-fixed: '#25005a'
  on-secondary-fixed-variant: '#5a00c6'
  tertiary-fixed: '#acedff'
  tertiary-fixed-dim: '#4cd7f6'
  on-tertiary-fixed: '#001f26'
  on-tertiary-fixed-variant: '#004e5c'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.005em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  code-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  gutter-lg: 2rem
  margin: 1.5rem
  margin-sm: 1rem
  margin-lg: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system embodies an intelligent, encouraging, and razor-sharp modern educational SaaS platform. It serves ambitious students and emerging professionals seeking data-driven clarity on their journey from academia to high-demand careers. The emotional tone balances the institutional trust of academic advisors with the kinetic, forward-looking precision of an AI tech co-pilot.

The aesthetic blends **Modern SaaS Minimalism** with subtle **Neo-Digital Precision**. Generous whitespace, razor-thin structural keylines, luminous indigo-to-violet energetic accents, and ultra-smooth tactile cards yield an interface that feels lightweight, focused, and free of cognitive clutter. The interface avoids cold corporate monotony by leveraging energetic cyan focus points, rich violet guidance pathways, and approachable geometric type curves.

## Colors

The palette leverages a pristine, cool-tinted canvas with layered depths and purposeful color assignments:

- **Canvas & Backgrounds:** The base viewport background rests at `#F8FAFC` (Slate 50), providing soft daylight comfort that minimizes eye fatigue. Elevated card containers and floating panels sit atop pure `#FFFFFF`, separated by a delicate hairline border token `#E5E7EB` (Gray 200).
- **Text & Hierarchy:** Primary typography uses high-contrast `#111827` (Gray 900) for uncompromised legibility. Secondary descriptors, placeholders, and structural metadata leverage `#64748B` (Slate 500).
- **Brand Signals:** Primary interactions, key action paths, and navigational states utilize `#4F46E5` (Indigo 600). `#7C3AED` (Violet 600) serves as the secondary brand dimension, reserved for AI recommendations, automated insights, and predictive analytics indicators.
- **Accents & States:** `#06B6D4` (Cyan 500) punctuates active progress, real-time match scores, and diagnostic tags. `#16A34A` (Green 600) represents resolved skill gaps, verified proficiencies, and positive feedback milestones.

## Typography

Typography establishes an assertive hierarchy between analytical storytelling and dense skill assessment dashboards:

- **Display & Headings (Plus Jakarta Sans):** Selected for its friendly geometry, confident counters, and modern proportions. Used across hero headers, key career score indicators, module card headings, and section banners to create an approachable yet contemporary SaaS identity.
- **Body & Controls (Inter):** Utilized for dashboard data grids, narrative guidance text, form labels, and comparative skill gap matrices. Its neutral mechanical structure and tall x-height guarantee effortless scanning across multi-tier curriculum comparisons and data-rich tables.

## Layout & Spacing

The system is constructed on an adaptable 8pt structural rhythm combined with a responsive 12-column grid:

- **Desktop (>= 1280px):** 12-column grid with `margin-lg` (48px) section insets and `gutter` (24px). Maximum application canvas width is capped at 1440px to ensure data density remains legible and dashboards avoid horizontal strain.
- **Tablet (768px - 1279px):** 8-column layout with `margin` (24px) canvas padding and `gutter-sm` (16px). Secondary sidebar panels collapse into drawer drawers or tabbed views.
- **Mobile (< 768px):** 4-column single-stack flow with `margin-sm` (16px) margins and `gutter-sm` (16px). Metrics panels reflow from horizontal summary ribbons into vertically stacked swipe cards.

## Elevation & Depth

Visual hierarchy uses a refined hybrid of **tonal layering**, **1px crisp perimeter borders**, and **soft, diffuse ambient shadows**:

- **Ground Level (Canvas):** Pure `#F8FAFC` base with no shadow or outline.
- **Level 1 (Resting Cards & Modules):** Pure `#FFFFFF` background bound by a continuous 1px outline in `#E5E7EB`. Elevated with an ambient shadow: `box-shadow: 0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.02)`.
- **Level 2 (Hover States, Interactive Cards & Dropdowns):** Subtle upward translation (-2px) on hover with an ambient violet-indigo tint: `box-shadow: 0 10px 25px -5px rgba(79, 70, 229, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.03)`. Border shifts slightly toward primary tint (`#C7D2FE`).
- **Level 3 (Modals, Skill Diagnostic Drawers & Overlays):** Deep ambient diffusion for floating surfaces: `box-shadow: 0 20px 35px -10px rgba(15, 23, 42, 0.12), 0 10px 10px -5px rgba(15, 23, 42, 0.04)`. Accompanied by a 20% `#0F172A` backdrop blur mask (`backdrop-filter: blur(4px)`).

## Shapes

The interface embraces generous, welcoming border radii that reinforce its modern student-first software design:

- **Base Cards & Container Panes:** Use `rounded-lg` (16px) for standard analytical widgets, course recommendation blocks, and benchmark comparison panels.
- **Major Dashboard Sections & Modals:** Use `rounded-xl` (24px) for hero diagnostic modules, milestone summaries, and elevated focus sheets.
- **Inputs, Buttons, & Interactive Chips:** Utilize a unified 10px to 12px corner radius (`rounded-md` through `rounded-lg`) for a comfortable touch target feel.
- **Badges, Tags, & Status Pills:** Full pill radius (`rounded-full` / 9999px) for skill proficiency tags, match percentages, and status alerts.

## Components

### Buttons
- **Primary:** Background `#4F46E5`, text `#FFFFFF`, font `label-md`. 12px vertical, 20px horizontal padding, rounded to 10px. Hover transitions to `#4338CA` with subtle glow shadow.
- **AI Action / Guidance:** Subtle horizontal linear gradient from `#4F46E5` to `#7C3AED`, white text, accompanied by an AI icon. Used exclusively for generating skill paths and running diagnostic audits.
- **Secondary / Outline:** Background `#FFFFFF`, border 1px solid `#E5E7EB`, text `#111827`. Hover transitions border to `#4F46E5` and text to `#4F46E5`.
- **Ghost:** Background transparent, text `#64748B`, hover background `#F1F5F9` and text `#111827`.

### Cards & Dashboards
- **Skill Insight Card:** `#FFFFFF` background, 16px corner radius, 1px `#E5E7EB` border, 24px inner padding. Contains a title (`title-md`), dynamic progress meter, and skill tag cluster.
- **Benchmark / Target Career Card:** 20px corner radius, crisp border, featuring a circular match gauge colored in `#06B6D4` (accent) or `#16A34A` (success).

### Chips & Badges
- **Skill Gap Chip (Missing):** Pill-shaped, background `#FEF2F2`, border 1px solid `#FECACA`, text `#DC2626`.
- **Proficient Skill Chip:** Pill-shaped, background `#F0FDF4`, border 1px solid `#BBF7D0`, text `#16A34A`.
- **AI Recommendation Tag:** Pill-shaped, background `#F5F3FF`, border 1px solid `#DDD6FE`, text `#7C3AED`.

### Input Fields & Controls
- **Text Inputs:** Height 44px, background `#FFFFFF`, border 1px solid `#E5E7EB`, text `#111827`, placeholder `#64748B`. Focused state introduces a 2px outer ring in `#4F46E5` with an offset of 1px.
- **Checkboxes & Radios:** 18px box with 5px radius (`rounded-sm`), 1.5px border `#CBD5E1`. Checked state fills `#4F46E5` with a white checkmark.

### Progress & Gap Visualizers
- **Skill Match Progress Bar:** Track height of 8px, background `#F1F5F9`, rounded pill track. Fill uses an energetic linear gradient from `#4F46E5` through `#06B6D4`.
- **Radar & Career Gap Charts:** Chart canvases leverage transparent backgrounds with grid lines in `#E2E8F0`, candidate fill in `#4F46E5` with 20% alpha, and market standard comparison lines in `#94A3B8`.